$.extend({
    mainMenu: new function () {
        var _self = this;
        var _course = null;
        var _serializeElements = false;
        var _hasAuraPlayer = false;
        _self.initialize = function () {
            _checkAuraPlayer();
            //load course menu
            _loadMenu();
        };

        var _checkAuraPlayer = function(){
            _hasAuraPlayer = window.parent.auraplayer && window.parent.auraplayer != "undefined" && window.parent.auraplayer != null && window.parent.auraplayer != "";
            _hasAuraPlayer = true; //remove this line when possible
        };

        var _performAuraPlayerTasks = function (){
            if (_hasAuraPlayer)
            {
                _attachTopicsBehavior();
                //_showConfirmationMessage();
                if (window.parent.setProgress)
                {
                    window.parent.setProgress();
                }
            }
        };

        var _getTopicParam = function (uIndex, tIndex, id){
            var param = _course.unit[uIndex].topic[tIndex].param;
            for (var i = 0; i < param.length; i++) {
                if (param[i].id == id)
                    return param[i].value;
            }
            return '';
        };

        var _loadMenu = function () {
            //store json value in _course field
            _course = shift.course;
            $('.course-name').html(_course.name);
            $('.title-units', $('.units-container')).html(_course.getParam('unit-menu-header-text'));
            $('.title-topics', $('.topics-container')).html(_course.getParam('topic-menu-header-text'));
            var _param = _course.getParam('serializeelements');
            _serializeElements = _param == 'true' ? true : false;
            _buildMenu();
            _setThemeColors();
            _setBulletColors();
            _performAuraPlayerTasks();
            $(window).unbind("resize");
            // setTimeout(function(){_resize();setTimeout(function(){$(window).resize();}, 1000);}, 100);
            // Add Resize handlers
            $(window).on("resize", function() {
                setTimeout(function(){
                    _resize();
                }, 100);
            });
            _fixIEBackgroundBug();
            _serializeElementsAlert();
        };

        var _serializeElementsAlert = function(){
            $('.topic').each(function(){
                $('a[activated=0]', $(this)).click(function(){
                    alert(_course.getParam('serializeelementsalert'));
                });
            });
        };

        var _setThemeColors = function(){
            var _backgroundMenuType = _course.getParam('menu-background-type');
            var _backgroundImage = _course.getParam('background-image');
            var _backgroundImageMobile = _course.getParam('background-image-mobile');
            var _backgroundColor = _course.getParam('background-color');
            var _backgroundAlpha = _course.getParam('background-alpha');
            var _headerColor = _course.getParam('header-background-color');
            var _headerAlpha = _course.getParam('header-alpha');
            var _headerTextColor = _course.getParam('header-text-color');
            var _modulesTitleColor = _course.getParam('modules-title-background-color');
            var _modulesTitleAlpha = _course.getParam('modules-title-alpha');
            var _unitsTitleColor = _course.getParam('units-title-background-color');
            var _unitsTitleAlpha = _course.getParam('units-title-alpha');
            var _unitsTitleTextColor = _course.getParam('units-title-text-color');
            var _topicsTitleColor = _course.getParam('topics-title-background-color');
            var _topicsTitleAlpha = _course.getParam('topics-title-alpha');
            var _topicsTitleTextColor = _course.getParam('topics-title-text-color');
            var _unitsContainerColor = _course.getParam('units-container-background-color');
            var _unitsContainerAlpha = _course.getParam('units-container-alpha');
            var _topicsContainerColor = _course.getParam('topics-container-background-color');
            var _topicsContainerAlpha = _course.getParam('topics-container-alpha');

            // For both desktop-menu and mobile-menu

            if (_headerColor !='') {
                $('.title', 'header', '.menu-container').css('background-color', (_headerAlpha != '') ? _hex2rgbAndOpacity(_headerColor, _headerAlpha) : _headerColor)
            };
            (_headerTextColor !='') ? $('.course-name', '.title', 'header', '.menu-container').css('color', _headerTextColor) : $('.course-name', '.title', 'header', '.menu-container').css('color', "#FFFFFF");
            if (_unitsTitleColor !='') {
                $('.title-units', '.title', '.units-container', '.menu-container').css('background-color', (_unitsTitleAlpha != '') ? _hex2rgbAndOpacity(_unitsTitleColor, _unitsTitleAlpha) : _unitsTitleColor)
            };
            (_unitsTitleTextColor !='') ? $('.title-units', '.title', '.units-container', '.menu-container').css('color', _unitsTitleTextColor) : $('.title-units', '.title', '.units-container', '.menu-container').css('color', "#FFFFFF");
            if (_topicsTitleColor !='') {
                $('.title-topics', '.title', '.topics-container', '.menu-container').css('background-color', (_topicsTitleAlpha != '') ? _hex2rgbAndOpacity(_topicsTitleColor, _topicsTitleAlpha) : _topicsTitleColor)
            };
            (_topicsTitleTextColor !='') ? $('.title-topics', '.title', '.topics-container', '.menu-container').css('color', _topicsTitleTextColor) : $('.title-topics', '.title', '.topics-container', '.menu-container').css('color', "#FFFFFF");

            // Only for desktop-menu
            if (_modulesTitleColor !='') {
                $('.title', '.desktop-menu', '.menu-container').css('background-color', (_modulesTitleAlpha != '') ? _hex2rgbAndOpacity(_modulesTitleColor, _modulesTitleAlpha) : _modulesTitleColor)
            };
            if (_unitsContainerColor !='' && _backgroundMenuType != 'color' && _backgroundMenuType != 'gradient') {
                $('.container.units', '.desktop-menu', '.menu-container').css('background-color', (_unitsContainerAlpha != '') ? _hex2rgbAndOpacity(_unitsContainerColor, _unitsContainerAlpha) : _unitsContainerColor)
            };
            if (_topicsContainerColor !='' && _backgroundMenuType != 'color' && _backgroundMenuType != 'gradient') {
                $('.container.topics', '.menu-container').css('background-color', (_topicsContainerAlpha != '') ? _hex2rgbAndOpacity(_topicsContainerColor, _topicsContainerAlpha) : _topicsContainerColor)
            };
            switch(_backgroundMenuType){
                case 'color':
                    if (_backgroundColor !='') {
                        $('body').css('background-color', (_backgroundAlpha != '') ? _hex2rgbAndOpacity(_backgroundColor, _backgroundAlpha) : _backgroundColor)
                    };
                    break;
                case 'gradient':
                    _setGradientColors();
                    break;
                case 'image':
                    _setBackgroundImage(_backgroundImage,_backgroundImageMobile);
                    break;


            }
        };

        var _setGradient = function(element, startColor, endColor, direction, alpha){
            if (startColor != '' && endColor != '') {
                var position = ['top', 'left bottom', 'to bottom', '0'];
                if (direction != '') {
                    position = (direction == 'V') ?  ['top', 'left bottom', 'to bottom', '0'] : ['left top', 'right top', 'to right', '1'];
                }
                element.css('filter', "progid:DXImageTransform.Microsoft.gradient(startColorStr='" + ((alpha != '') ? _dec2hexAndOpacityIE(startColor, alpha) : startColor) + "', EndColorStr='" + ((alpha != '') ? _dec2hexAndOpacityIE(endColor, alpha) : endColor) + "', GradientType='" + position[3] + "')")
                .css('background-image', '-moz-linear-gradient(' + position[0] + ', ' + ((alpha != '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + ' 0%, ' + ((alpha != '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + ' 100%)')
                .css('background-image', 'linear-gradient(' + position[0] + ', ' + ((alpha != '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + ' 0%, ' + ((alpha != '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + ' 100%)')
                .css('background-image', '-o-linear-gradient(' + position[0] + ', ' + ((alpha != '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + ' 0%, ' + ((alpha != '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + ' 100%)')
                .css('background-image', '-webkit-linear-gradient(' + position[0] + ', ' + ((alpha != '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + ' 0%, ' + ((alpha != '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + ' 100%)')
                .css('background-image', '-ms-linear-gradient(' + position[0] + ', ' + ((alpha != '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + ' 0%, ' + ((alpha != '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + ' 100%)')
                .css('background-image', '-webkit-gradient(linear, left top, ' + position[1] + ', from(' + ((alpha != '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + '), to(' + ((alpha != '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + '))')
                .css('background-image', 'linear-gradient(' + position[2] + ', ' + ((alpha != '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + ' 0%, ' + ((alpha != '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + ' 100%)')
                .css('background-color', '');
            }
        };

        var _setGradientColors = function(){
            var _backgroundGradientStartColor = _course.getParam('background-gradient-start-color');
            var _backgroundGradientEndColor = _course.getParam('background-gradient-end-color');
            var _headerGradientStartColor = _course.getParam('header-gradient-start-color');
            var _headerGradientEndColor = _course.getParam('header-gradient-end-color');
            var _modulesTitleGradientStartColor = _course.getParam('modules-title-gradient-start-color');
            var _modulesTitleGradientEndColor = _course.getParam('modules-title-gradient-end-color');
            var _unitsTitleGradientStartColor = _course.getParam('units-title-gradient-start-color');
            var _unitsTitleGradientEndColor = _course.getParam('units-title-gradient-end-color');
            var _topicsTitleGradientStartColor = _course.getParam('topics-title-gradient-start-color');
            var _topicsTitleGradientEndColor = _course.getParam('topics-title-gradient-end-color');
            var _unitsContainerGradientStartColor = _course.getParam('units-container-gradient-start-color');
            var _unitsContainerGradientEndColor = _course.getParam('units-container-gradient-end-color');
            var _topicsContainerGradientStartColor = _course.getParam('topics-container-gradient-start-color');
            var _topicsContainerGradientEndColor = _course.getParam('topics-container-gradient-end-color');

            // For both desktop-menu and mobile-menu
            _setGradient($('body'), _backgroundGradientStartColor, _backgroundGradientEndColor, _course.getParam('background-gradient-direction'), _course.getParam('background-alpha'));
            _setGradient($('.title', 'header', '.menu-container'), _headerGradientStartColor, _headerGradientEndColor, _course.getParam('header-gradient-direction'), _course.getParam('header-alpha'));
            _setGradient($('.title-units', '.title', '.units-container', '.menu-container'), _unitsTitleGradientStartColor, _unitsTitleGradientEndColor, _course.getParam('units-title-gradient-direction'), _course.getParam('units-title-alpha'));
            _setGradient($('.title-topics', '.title', '.topics-container', '.menu-container'), _topicsTitleGradientStartColor, _topicsTitleGradientEndColor, _course.getParam('topics-title-gradient-direction'), _course.getParam('topics-title-alpha'));

            // Only for desktop-menu
            _setGradient($('.title', '.desktop-menu', '.menu-container'), _modulesTitleGradientStartColor, _modulesTitleGradientEndColor, _course.getParam('modules-title-gradient-direction'), _course.getParam('modules-title-alpha'));
            _setGradient($('.container.units', '.desktop-menu', '.menu-container'), _unitsContainerGradientStartColor, _unitsContainerGradientEndColor, _course.getParam('units-container-gradient-direction'), _course.getParam('units-container-alpha'));
            _setGradient($('.container.topics', '.desktop-menu', '.menu-container'), _topicsContainerGradientStartColor, _topicsContainerGradientEndColor, _course.getParam('topics-container-gradient-direction'), _course.getParam('topics-container-alpha'));
        };

        var _setBulletColors = function(){
            // units bullets background, border and fill colors
            var _unitsBulletsBorderColor = _course.getParam('units-bullets-border-color');
            var _unitsBulletsBackgroundColor = _course.getParam('units-bullets-background-color');
            var _unitsBulletsFillColor = _course.getParam('units-bullets-fill-color');
            (_unitsBulletsBorderColor != '') ? $('.units-status').css('border-color', _unitsBulletsBorderColor) : $('.units-status').css('border-color', '#000000');
            (_unitsBulletsBackgroundColor != '') ? $('.units-status').css('background-color', _unitsBulletsBackgroundColor) : $('.units-status').css('background-color', '#8a8a8a');
            (_unitsBulletsFillColor != '') ? $('span', $('.units-status')).css('background-color', _unitsBulletsFillColor) : $('span', $('.units-status')).css('background-color', '#8a8a8a');

            // topics bullets background, border and fill colors
            var _topicsBulletsBorderColor = _course.getParam('topics-bullets-border-color');
            var _topicsBulletsBackgroundColor = _course.getParam('topics-bullets-background-color');
            var _topicsBulletsFillColor = _course.getParam('topics-bullets-fill-color');
            (_topicsBulletsBorderColor != '') ? $('.topics-status').css('border-color', _topicsBulletsBorderColor) : $('.topics-status').css('border-color', '#000000');
            (_topicsBulletsBackgroundColor != '') ? $('.topics-status').css('background-color', _topicsBulletsBackgroundColor) : $('.topics-status').css('background-color', '#8a8a8a');
            (_topicsBulletsFillColor != '') ? $('span', $('.topics-status')).css('background-color', _topicsBulletsFillColor) : $('span', $('.topics-status')).css('background-color', '#8a8a8a');
        };

        var _setBackgroundImage = function(_backgroundImage, _backgroundImageMobile){
            $(".menu-container").height($(window).height());
            if (!$("#image_stretch_field_v")[0]){
                var current_item = $('.menu-container');
                current_item.prepend(
                    $("<div>").attr({
                        "id": "image_stretch_field_v",
                        "data-src-stretch" : 'img/' + _backgroundImageMobile,
                        "data-alt-stretch": current_item.content
                    })
                    .css({
                        "width" : "100%",
                        "height" : "100%",
                        "margin": "0",
                        "position" : "absolute",
                        "overflow" : "hidden"
                    })
                    .addClass("stretchBackgroundImage")
                    );

                $(".stretchBackgroundImage").imagestretch();
                setTimeout( function() {
                    $(window).trigger("resize");
                //$(window).trigger('orientationchange');
                }, 100);
            }
            $(".menu-container").height($(window).height());
            if (!$("#image_stretch_field")[0]){
                var current_item = $('.menu-container');
                current_item.prepend(
                    $("<div>").attr({
                        "id": "image_stretch_field",
                        "data-src-stretch" : 'img/' + _backgroundImage,
                        "data-alt-stretch": current_item.content
                    })
                    .css({
                        "width" : "100%",
                        "height" : "100%",
                        "margin": "0",
                        "position" : "absolute",
                        "overflow" : "hidden"
                    })
                    .addClass("stretchBackgroundImage")
                    );

                $(".stretchBackgroundImage").imagestretch();
                setTimeout( function() {
                    $(window).trigger("resize");
                //$(window).trigger('orientationchange');
                }, 100);
            }
            $('body').css('background-color', '#ffffff');
        };

        var _resize = function(){
            var units = $('.container.units', '.units-container', '.menu-container');
            var topics = $('.container.topics', '.topics-container', '.menu-container');

            var mobileUnits = $('.container.units', '.mobile-menu', '.menu-container');
            var mobileTopics = $('.container.topics', '.mobile-menu', '.menu-container');

            units.css('height', '');
            topics.css('height', '');
            mobileUnits.css('height', '');
            mobileTopics.css('height', '');
            $('.logo-container', '.units-container', '.menu-container').css('height', '');
            $('.logo-container', '.topics-container', '.mobile-menu', '.menu-container').css('height', '');
            var unitsContainerHeight = units.height() - $('.logo-container', '.units-container', '.menu-container').height();
            //var topicsContainerHeight = movileTopicsContainer.height() - $('.logo-container', '.topics-container', '.mobile-menu', '.menu-container').height();
            var _height = $(window).height();
            var _desktopMenuVisible = $('.desktop-menu:visible').length > 0;

            //restore the body width to fix IE bug
            $('body').css('width', '100%');
            if (_desktopMenuVisible) {
                _setThemeColors();
                units.height(_height - ($('.title', 'header', '.menu-container').height() + $('.title', '.units-container', '.menu-container').height())*2 + 'px' );
                topics.height(_height - ($('.title', 'header', '.menu-container').height() + $('.title', '.topics-container', '.menu-container').height())*2 + 'px' );

                $('.logo-container', '.units-container', '.menu-container').height(units.height() - unitsContainerHeight);
                setTimeout( function() {
                    $('.logo-container').css('display', 'block');
                }, 200);
                (units.height() >= ($('.logo-container', '.units-container', '.menu-container').position().top - $('.logo', '.logo-container', '.units-container', '.menu-container').height() - 10)) ? units.height(_height - ($('.title', 'header', '.menu-container').height() + $('.title', '.units-container', '.menu-container').height())*2 + 'px' ) : units.css('height', '');
                topics.height(units.height()).css('margin-left', '');
                $('img.logo', '.units-container', '.menu-container').css('position', '');
            } else {
                _logoPosition();
            }

            var _menuHeight = $(window).height();
            var _backgroundImage = _course.getParam('background-image');
            var _backgroundGradientStartColor = _course.getParam('background-gradient-start-color');
            var _backgroundGradientEndColor = _course.getParam('background-gradient-end-color');
            if (_backgroundImage !='' || (_backgroundGradientStartColor !='' && _backgroundGradientEndColor !='')) {
                // if((navigator.userAgent.match(/iPad/i)) || (navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i)) || (navigator.userAgent.match(/Android/i))) {
                // resize body to resize the background-image
                // resize menu-container to resize and stretch the image
                // On mobile the bind dispatched is orientationchange
                $(window).bind('orientationchange', function(event) {
                    $(window).unbind('orientationchange');
                    if (_backgroundImage !='' || (_backgroundGradientStartColor !='' && _backgroundGradientEndColor !='')) {
                        _menuHeight = $(window).height();
                        $(".menu-container").css({
                            'height': '',
                            'min-height': _menuHeight +'px'
                            });//height(_menuHeight);
                        if (($(window).width()<960)) {
                            // The background image must not be visible qhen is available
                            $('#image_stretch_field', '.menu-container').css('display', 'none');
                            $('#image_stretch_field_v', '.menu-container').css('display', 'block');
                            // The background-color and background-gradient must be visible when are available
                            switch(_course.getParam('menu-background-type')){
                                case 'color':
                                    if (_course.getParam('background-color') !='') {
                                        $('body').css('background-color', (_course.getParam('background-alpha') != '') ? _hex2rgbAndOpacity(_course.getParam('background-color'), _course.getParam('background-alpha')) : _course.getParam('background-color'))
                                    }
                                    break;
                                case 'gradient':
                                    _setGradient($('body'), _course.getParam('background-gradient-start-color'), _course.getParam('background-gradient-end-color'), _course.getParam('background-gradient-direction'), _course.getParam('background-alpha'));
                                    break;
                                case 'image':
                                    break;
                                default:
                                    if (_course.getParam('units-container-background-color') !='') {
                                        $('.container.units', '.desktop-menu', '.menu-container').css('background-color', (_course.getParam('units-container-alpha') != '') ? _hex2rgbAndOpacity(_course.getParam('units-container-background-color'), _course.getParam('units-container-alpha')) : _course.getParam('units-container-background-color'))
                                    }
                                    if (_course.getParam('topics-container-background-color') !='') {
                                        $('.container.topics', '.menu-container').css('background-color', (_course.getParam('topics-container-alpha') != '') ? _hex2rgbAndOpacity(_course.getParam('topics-container-background-color'), _course.getParam('topics-container-alpha')) : _course.getParam('topics-container-background-color'))
                                    }
                                    _setGradient($('.container.units', '.desktop-menu', '.menu-container'), _course.getParam('units-container-gradient-start-color'), _course.getParam('units-container-gradient-end-color'), _course.getParam('units-container-gradient-direction'), _course.getParam('units-container-alpha'));
                                    _setGradient($('.container.topics', '.desktop-menu', '.menu-container'), _course.getParam('topics-container-gradient-start-color'), _course.getParam('topics-container-gradient-end-color'), _course.getParam('topics-container-gradient-direction'), _course.getParam('topics-container-alpha'));
                                    if (($('.topics-container', '.mobile-menu', '.menu-container').height() + $('.units-container', '.mobile-menu', '.menu-container').height() + $('header', '.menu-container').height() + $('img.logo', '.topics-container', '.mobile-menu', '.menu-container').height() + 10) > $(window).height()) {
                                        _menuHeight = ($('.topics-container', '.mobile-menu', '.menu-container').height() + $('.units-container', '.mobile-menu', '.menu-container').height() + $('header', '.menu-container').height() + $('img.logo', '.topics-container', '.mobile-menu', '.menu-container').height() + 35);
                                    }
                                    break;
                            }
                        } else {
                            // The background image must be visible when is available
                            $('#image_stretch_field', '.menu-container').css('display', 'block');
                            $('#image_stretch_field_v', '.menu-container').css('display', 'none');
                            // The background-color and background-gradient must not be visible when image is available
                            if (_course.getParam('menu-background-type') == 'image') {
                                $('body').css({
                                    'background-color' : '#ffffff',
                                    'background-image' : 'none'
                                });
                                units.css({
                                    'background-color' : '',
                                    'background-image' : 'none'
                                });
                                topics.css({
                                    'background-color' : '',
                                    'background-image' : 'none'
                                });
                            };
                            if (($('.units-container', '.desktop-menu', '.menu-container').height() + $('header', '.menu-container').height() + 10) > $(window).height()) {
                                _menuHeight = ($('.units-container', '.desktop-menu', '.menu-container').height() + $('header', '.menu-container').height() + 10);
                            }
                            $(".stretchBackgroundImage").imagestretch('', '', 'right-bottom');
                        }
                        $('body').css('min-height', _menuHeight + 'px').css({
                            'background-size': '100% ' + _menuHeight + 'px',
                            '-webkit-background-size': '100% ' + _menuHeight + 'px',
                            '-moz-background-size': '100% ' + _menuHeight + 'px',
                            '-o-background-size': '100% ' + _menuHeight + 'px',
                            'background-repeat': 'no-repeat'
                        });
                        $(".menu-container").css({
                            'height': '',
                            'min-height': _menuHeight +'px'
                            });//height(_menuHeight);
                    };
                });
                // }
                $('body').css({
                    'height': '',
                    'min-height': ''
                });
                $('body').css('min-height', _height + 'px').css({
                    'background-size': '100% ' + _height + 'px',
                    '-webkit-background-size': '100% ' + _height + 'px',
                    '-moz-background-size': '100% ' + _height + 'px',
                    '-o-background-size': '100% ' + _height + 'px',
                    'background-repeat': 'no-repeat'
                });
                $(".menu-container").css({
                    'height': '',
                    'min-height': _height +'px'
                    });//height(_height);
            }
            $(window).trigger('orientationchange');
            _fixIEBackgroundBug();
        };

        var _fixIEBackgroundBug = function(){
            var item = $('.imagestretch');
            var myNav = navigator.userAgent.toLowerCase();
            var version = (myNav.indexOf('msie') != -1) ? parseInt(myNav.split('msie')[1]) : 0;
            if ((version == 9 || shift.screen.isWebkit) && item.length > 0){
                item.css('z-index', 0);
                $('header').css('position', 'relative');
                $('.desktop-menu').css('position', 'relative');
            }
        };

        var _logoPosition = function(isSlideDown){
            var _height = $(window).height();
            $('.logo-container', '.mobile-menu', '.menu-container').height(_height - (($('.title', 'header', '.mobile-menu', '.menu-container').height()*2) + $('.units-container', '.mobile-menu', '.menu-container').height()) + 10 + 'px');
            $('.logo-container', '.mobile-menu', '.menu-container').css({
                'position': 'relative',
                'width': '',
                'bottom': '',
                'right': ''
            });
            if (isSlideDown && $('.logo-container', '.mobile-menu', '.menu-container').height() > 102)
                $('.logo-container', '.mobile-menu', '.menu-container').css({
                    'position': 'fixed',
                    'width': '140px',
                    'height': '',
                    'bottom': '0px',
                    'right': '0px'
                });
        };

        var _buildMenu = function () {
            _attachMenuBehavior('desktop-menu');
            _attachMenuBehavior('mobile-menu');
            if(_course.getParam('collapsable-menu')&&_course.getParam('collapsable-menu')=='true'){
                //set visible mobile-menu
                $('.mobile-menu', '.menu-container').show();
                $('.desktop-menu', '.menu-container').hide();
                $('.mobile-menu', '.menu-container').css({
                    'display':'block'
                });
                $('.desktop-menu', '.menu-container').css({
                    'display':'none'
                });
            }
        };

        var _attachTopicsBehavior = function(){
            $('.topic').each(function(){
                $('a[activated=1]', $(this)).click(function(){
                    var _item = $(this);
                    //play the first screen
                    var uIndex = _item.attr('unit-index');
                    var tIndex = _item.attr('index');
                    var topicIsTest = _getTopicParam(uIndex, tIndex, 'istest');
                    var showTest = _course.getParam('showtestmessagestext');
                    if ((topicIsTest == 'true' && showTest == 'true') || (topicIsTest == 'true' && typeof(showTest) == 'string' && showTest.length == 0)) {
                        showTestStartConfirmation(uIndex, tIndex, 0);
                        return;
                    }
                    shift.screen.show(uIndex, tIndex, 0);
                });
            });
        };

        var showTestStartConfirmation = function(uIndex, tIndex, sIndex){
            var buttons = {};
            buttons[_course.getParam('yes-text')] = function(){
                $(this).dialog("close");
                shift.course.initializeCountDownVariables();
                shift.course.hideRandomEvaluations(uIndex, tIndex, sIndex);
                shift.screen.show(uIndex, tIndex, sIndex);
            };
            buttons[_course.getParam('no-text')] = function(){
                $(this).dialog("close");
            };
            MessageBox.alert(_course.getParam('alert-text'), _course.getParam('test-start-confirmation-message'), buttons, null, false);
        };

        var _loadUnits = function(containerType){
            var container = $('.'+containerType);
            var _unitsContainer = $('.units', container);
            var _unitsContainerTextColor = _course.getParam('units-container-text-color');
            // if (containerType == 'desktop-menu') _unitsContainerTextColor = _course.getParam('units-container-text-color');
            // else if (containerType == 'mobile-menu') _unitsContainerTextColor = _course.getParam('units-title-text-color');
            var _topicsContainerTextColor = _course.getParam('topics-container-text-color');

            if (_course.unit.length > 0)
            {
                for(var i=0;i<_course.unit.length;i++)
                {
                    var j = i + 1;
                    var _numericalSequence = _course.getParamBool('numerical-sequence', false);
                    var _topicsHtml = _getTopicsHtml(i, _course.unit[i]);
                    var _unitHtml;
                    var _topicsContainer;

                    if(checkUnit(_course.unit[i])){
                        if (containerType == 'desktop-menu') {
                            if (_numericalSequence == true) {
                                _unitHtml = '<a href="javascript:void(0);" index="' + i + '">' + _getStatusBullet('units', shift.mainMenu.getUnitStatus(i)) + '<span>' + j + '. ' + _course.unit[i].name + '</span></a>';
                            }
                            else {
                                _unitHtml = '<a href="javascript:void(0);" index="' + i + '">' + _getStatusBullet('units', shift.mainMenu.getUnitStatus(i)) + '<span>' + _course.unit[i].name + '</span></a>';
                            }
                            _addHtml(_unitsContainer, _unitHtml);
                            _topicsContainer = $('.topics', container);
                        } else if (containerType == 'mobile-menu') {
                            if (_numericalSequence == true) {
                                _unitHtml = '<div class="title"><div class="title-units"><a href="javascript:void(0);" index="' + i + '">' + _getStatusBullet('units', shift.mainMenu.getUnitStatus(i)) + '<span>' + j + '. ' + _course.unit[i].name + '</span></a></div></div>'
                                + '<div class="topics-container"><nav class="container topics" index="' + i +'"/></div>';
                            }
                            else {
                                _unitHtml = '<div class="title"><div class="title-units"><a href="javascript:void(0);" index="' + i + '">' + _getStatusBullet('units', shift.mainMenu.getUnitStatus(i)) + '<span>' + _course.unit[i].name + '</span></a></div></div>'
                                + '<div class="topics-container"><nav class="container topics" index="' + i +'"/></div>';
                            }
                            _addHtml(_unitsContainer, _unitHtml);
                            _topicsContainer = $('.topics[index=' + i + ']', container);
                            _topicsContainer.hide();
                        }

                        _addHtml(_topicsContainer, _topicsHtml);
                    // _mobileUnitsContainer.append(_unitHtml + _topicsHtml);
                    }


                }
            }
            _unitsContainerTextColor != '' ? $('a', $('.container.units', container)).css('color', _unitsContainerTextColor) : $('a', $('.container.units', '.units-container')).css('color', "#FFFFFF");
            _topicsContainerTextColor != '' ? $('a', $('.container.topics', '.topics-container')).css('color', _topicsContainerTextColor) : $('a', $('.container.topics', '.topics-container')).css('color', "#FFFFFF");

        };
        var checkUnit = function(unit)
        {

            if(unit.topic.length > 0)
            {
                var topicWithScreen = unit.topic.filter(function(item){


                    return(item.screen.length > 0);


               // return (item.topic.length > 0 && topics.length > 0);
                });
                return (topicWithScreen.length > 0);
            }else{
                return false;
            }




        }

        var _addHtml = function (containers, html){
            containers.each(function(){
                var _container = $(this);
                var _logoContainer = $('.logo-container', _container);
                if (_logoContainer.length > 0) {
                    _logoContainer.before(html);
                }
                else _container.append(html);
            });
        };

        var _getStatusBullet = function (itemType, status){
            return '<span class="' + itemType + '-status status-' + status + '"><span></span></span>';
        };

        var _getTopicsHtml = function(uIndex, unit){
            var _enableUnit = _canEnableUnit(uIndex);
            var _topicsHtml = '<div class="topic" index="' + uIndex + '" style="display:none;">';
            var _numericalSequence = _course.getParamBool('numerical-sequence', false);
            var j = uIndex + 1;

            if (unit.topic.length > 0)
            {
                for(var i=0;i<unit.topic.length;i++)
                {
                    if(unit.topic[i].screen.length >0){
                        var k = i + 1;
                        var _enableTopic = _canEnableTopic(uIndex, i);
                        var _canActivate = _enableUnit && _enableTopic ? '1' : "0";

                        _topicsHtml += '<a href="javascript:void(0);" unit-index="' + uIndex + '" index="' + i + '" activated="'+ _canActivate +'">';
                        if (_numericalSequence == true) {
                            _topicsHtml += _getStatusBullet('topics', shift.mainMenu.getTopicStatus(uIndex, i)) + '<span>' + j + '.' + k + '. ' + unit.topic[i].name + '</span></a>';
                        }
                        else {
                            _topicsHtml += _getStatusBullet('topics', shift.mainMenu.getTopicStatus(uIndex, i)) + '<span>' + unit.topic[i].name + '</span></a>';
                        }
                    }
                }
            }
            _topicsHtml += '</div>';
            return _topicsHtml;
        };

        var _previousUnitsEnabled = function(index){
            for (var i=0;i<index;i++){
                var _status = shift.mainMenu.getUnitStatus(i);
                if (_status == 0 || _status == 1) return false;
            }
            return true;
        };

        var _previousTopicsEnabled = function(unitIndex, topicIndex){
            for (var i=0;i<topicIndex;i++){
                var _status = shift.mainMenu.getTopicStatus(unitIndex, i);
                if (_status == 0 || _status == 1) return false;
            }
            return true;
        };

        var _getUnitSerializeParam = function(unitIndex) {
            return _course.getUnitParam("serializeelements", unitIndex) == 'true'
        };

        var _canEnableUnit = function(unitIndex){
            return !_serializeElements || _previousUnitsEnabled(unitIndex);
        };

        var _canEnableTopic = function (unitIndex, topicIndex){
            var unitSerializeElements = _getUnitSerializeParam(unitIndex);
            return (!_serializeElements && !unitSerializeElements) || _previousTopicsEnabled(unitIndex, topicIndex);
        };

        var _attachMenuBehavior = function(containerType){
            var container = $('.'+containerType);
            _loadUnits(containerType);

            if (containerType == 'mobile-menu')
                {
                    var _unit = $( '.title-units > a[index]', $('.units',container));
                }
            else
                {
                    var _unit = $( 'a[index]', $('.units',container));
                }


            _unit.click(function(){
                _openUnit($(this).attr('index'), containerType);
            });
            //----------------------------------------------------
            _openUnit(shift.screen.path.uIndex, containerType);
        };

        var _openUnit = function(index, containerType) {
            var container = $('.'+containerType);
            if ($('.topic[index=' + index + ']:visible', container).length == 0)
            {
                $('a', $('.units',container)).removeClass('selected');
                $('a[index=' + index + ']', container).addClass('selected');
                if (containerType == 'mobile-menu') {
                    $('.topic:visible', container).parent().hide();
                    $('.topic[index=' + index + ']', container).parent().show();
                }
                $('.topic:visible', container).hide();
                $('.topic a', container).removeClass('selected');
                // The logo-container must be positioned avery time a menu unit is clicked
                _logoPosition(true);
                $('.topic[index=' + index + ']', container).slideDown('fast', function() {
                    _logoPosition(false);
                });
            }
        };

        function _hex2rgbAndOpacity(hex, opacity) {
            var h=hex.replace('#', '');
            h =  h.match(new RegExp('(.{'+h.length/3+'})', 'g'));
            for(var i=0; i<h.length; i++)
                h[i] = parseInt(h[i].length==1? h[i]+h[i]:h[i], 16);
            if (typeof opacity != 'undefined')  h.push(opacity);
            return 'rgba('+h.join(',')+')';
        }

        function _dec2hexAndOpacityIE(hex, opacity) {
            var d;
            if (typeof opacity != 'undefined')  d = Math.floor(opacity * 255).toString(16);
            var h=hex.replace('#', '');
            d = d + h;
            return '#'+d;
        }
    }
});

$(function () {
    $.mainMenu.initialize();
    $(window).resize();
});
