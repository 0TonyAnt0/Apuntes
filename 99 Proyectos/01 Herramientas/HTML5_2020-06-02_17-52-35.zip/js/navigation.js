$.extend({
    navigation: new function() {
        var _self = this;
        var _course = null;

        _self.initialize = function() {
            //load course navigation
            _loadNavigation();
        };

        var _loadNavigation = function() {
            //store json value in _course field
            _course = shift.course;
            _setNavigationThemeColors();
            setTimeout(function() {
                _resize();
                setTimeout(function() {
                    $(window).resize();
                    setTimeout(function() {
                        $(window).resize();
                    }, 1000);
                }, 1000);
            }, 100);
        };

        var _setNavigationThemeColors = function() {
            var _navigationBackgroundType = _course.getParam('navigation-background-type');
            console.log(_navigationBackgroundType);
            var _navigationBackgroundImage = _course.getParam('navigation-background-image');
            var _navigationBackgroundImageUploaded = _course.getParam('navigation-background-image-uploaded');
            var _logoNavigationImageUploaded = _course.getParam('logo-navigation-image-uploaded');
            if (_navigationBackgroundImageUploaded === '') {
                _navigationBackgroundImageUploaded = _navigationBackgroundImage !== ''?'true':'false';
            }
            if (_logoNavigationImageUploaded === '') {
                _logoNavigationImageUploaded = _course.getParam('logo-nav') !== ''?'true':'false';
            }
            var _navigationBackgroundColor = _course.getParam('navigation-background-color');
            var _boxShadowColor = _course.getParam('box-frame-shadow-color');
            var _navigationBackgroundAlpha = _course.getParam('navigation-background-alpha');
            var _topRowNavigationColor = _course.getParam('top-row-navigation-background-color');
            var _topRowNavigationAlpha = _course.getParam('top-row-navigation-alpha');
            var _topRowNavigationTextColor = _course.getParam('top-row-navigation-text-color');
            var _centerRowNavigationColor = _course.getParam('center-row-navigation-background-color');
            var _centerRowNavigationTextColor = _course.getParam('center-row-navigation-text-color');
            var _bottomRowNavigationColor = _course.getParam('bottom-row-navigation-background-color');
            var _bottomRowNavigationTextColor = _course.getParam('bottom-row-navigation-text-color');
            var _logoNavigationBackgroundColor = _course.getParam('logo-navigation-background-color');
            var _logoNavigationBackgroundImage = _course.getParam('logo-navigation-background-image');
            var _pointerRowNavigationBackgroundColor = _course.getParam('pointer-row-navigation-background-color-vertical');
            var _pointerRowNavigationAlpha = _course.getParam('pointer-row-navigation-alpha-vertical');
            var _pointerRowNavigationTextColor = _course.getParam('pointer-row-navigation-text-color-vertical');
            var imageSprite = 'nav' + _navigationBackgroundImage.replace("navigation_background_","").replace("jpg","png");
            
            var possitionLeft = '0';
            var heightSize = '450%';
            if (imageSprite === 'nav22.png') possitionLeft = '-5px';
            if (imageSprite === 'nav21.png') heightSize = '300%';
            
            /*if (_logoNavigationImageUploaded === 'true') {
                $('.logo-container img').attr("src", "img/" + _course.getParam('logo-nav'));
            }else{
                $('.logo-container img').css('width', '140px').css('height', '100%').css('background-image', 'url(img/'+imageSprite+')').css('background-position',possitionLeft + ' 64.516129%').css('background-size','1182.67% ' + heightSize);
            }*/
            
            //$('.button-go-back').css('width', '33px').css('background-image', 'url(img/'+imageSprite+')').css('background-position','0 84.965831%').css('background-size','5818.181818%');
            //$('.button-go-menu').css('width', '33px').css('background-image', 'url(img/'+imageSprite+')').css('background-position','0 77.448747%').css('background-size','5818.181818%');
            //$('.button-go-forward').css('width', '33px').css('background-image', 'url(img/'+imageSprite+')').css('background-position','0 92.482916%').css('background-size','5818.181818%');

            // For desktop-menu
            if (_navigationBackgroundType == 'color') {
                if (_navigationBackgroundColor !== '') {
                    $('.desktop-navigation').css('background-color', (_navigationBackgroundAlpha !== '') ? _hex2rgbAndOpacity(_navigationBackgroundColor, _navigationBackgroundAlpha) : _navigationBackgroundColor)
                    _setNavigationButtonsRowPosition();
                };
            }
            if (_topRowNavigationColor !== '') {
                $('.top-navigation-container.main', '.desktop-navigation').css('background-color', (_topRowNavigationAlpha !== '') ? _hex2rgbAndOpacity(_topRowNavigationColor, _topRowNavigationAlpha) : _topRowNavigationColor)
            };
            if (_topRowNavigationTextColor !== '') {
                $('.top-navigation-container', '.desktop-navigation').css('color', _topRowNavigationTextColor)
            };
            if (_centerRowNavigationColor !== '') {
                $('.center-navigation-container.main').css('background-color', _centerRowNavigationColor)
            };
            if (_centerRowNavigationTextColor !== '') {
                $('.center-navigation-container').css('color', _centerRowNavigationTextColor)
            };
            if (_bottomRowNavigationColor !== '') {
                $('.bottom-navigation-container.main').css('background-color', _bottomRowNavigationColor)
            };
            if (_bottomRowNavigationTextColor !== '') {
                $('.bottom-navigation-container').css('color', _bottomRowNavigationTextColor)
            };

            // For mobile-menu
            if (_navigationBackgroundColor !== '') {
                $('.top-navigation-container.main', '.mobile-navigation').css('background-color', _navigationBackgroundColor)
            };
            if (_pointerRowNavigationBackgroundColor !== '') {
                $('.pointer-navigation-container', '.mobile-navigation').css('background-color', (_pointerRowNavigationAlpha !== '') ? _hex2rgbAndOpacity(_pointerRowNavigationBackgroundColor, _pointerRowNavigationAlpha) : _pointerRowNavigationBackgroundColor)
            };
            if (_pointerRowNavigationAlpha !== '' && _pointerRowNavigationBackgroundColor == '') {
                $('.pointer-navigation-container', '.mobile-navigation').css('background-color', _hex2rgbAndOpacity("#FFFFFF", _pointerRowNavigationAlpha))
            };
            if (_pointerRowNavigationTextColor !== '') {
                $('.pointer').css('color', _pointerRowNavigationTextColor)
            };

            // For both desktop-menu and mobile-menu
            if (_logoNavigationBackgroundColor !== '') {
                $('.logo-container').css('background-color', _logoNavigationBackgroundColor)
            };

            if (_navigationBackgroundType == 'gradient') {
                _setNavigationGradientColors();
            }

            if (_navigationBackgroundType == 'image') {
                if (_navigationBackgroundImage !== '') {
                    _setNavigationImage($('.desktop-navigation'), _navigationBackgroundImage, 'background-image', 0, _navigationBackgroundImageUploaded === 'true');
                    _setNavigationImage($('.top-navigation-container.main', '.mobile-navigation'), _navigationBackgroundImage, 'background-image', 0, _navigationBackgroundImageUploaded === 'true');
                    _setNavigationButtonsRowPosition();
                };
            }

            if (_logoNavigationBackgroundImage !== '') {
                //_setNavigationImage($('.logo-container', '.desktop-navigation'), _logoNavigationBackgroundImage, 'logo-background-image', '');
                //_setNavigationImage($('.logo-container', '.mobile-navigation'), _logoNavigationBackgroundImage, 'logo-background-image', '');
            };

            var _navigationTopicName = _course.getParam('navigation-topic-name');
            if (_navigationTopicName == 'true') {
                _activeTopicName();
            }
            hideButtons();
        };

        var hideButtons = function(){
            var hidePrint = _course.getParam('navigation-hide-print') == 'true'? true:false;
            var hideGlossary = true;//_course.getParam('navigation-hide-glossary') == 'true'? true:false;
            var hidePrintMobile = _course.getParam('navigation-hide-print-mobile') == 'true'? true:false;
            var hideGlossaryMobile = true;//_course.getParam('navigation-hide-glossary-mobile') == 'true'? true:false;
                        
            if (shift.screen.isMobilePhone) {
                if (hidePrintMobile && hideGlossaryMobile) {
                    $('.mobile-glossary').addClass('d-n');
                    $('.button-print').parent().hide();
                    $('.mobile-play-pause').addClass('button-audio-left');
                    $('.mobile-play-pause').addClass('left-0');
                    $('.mobile-play-pause').parent().parent().css('border-right-style','none');
                }else if (hidePrintMobile) {
                    $('.button-print').parent().hide();
                    $('.mobile-play-pause').addClass('button-audio-left');
                    $('.mobile-play-pause').addClass('left-second');
                    $('.mobile-play-pause').parent().parent().css('border-right-style','none');
                }else if (hideGlossaryMobile) {
                    $('.mobile-glossary').addClass('d-n');
                    $('.mobile-play-pause').addClass('button-audio-left');
                    $('.mobile-play-pause').addClass('left-zero');
                    $('.mobile-play-pause').addClass('left-second');
                    $('.mobile-play-pause').parent().parent().css('border-right-style','none');
                    $('.button-print').parent().addClass('left-0');
                }
            }else{
                if (hidePrint && hideGlossary) {
                    $('.mobile-glossary').addClass('d-n');
                    $('.button-print').parent().hide();
                    $('.mobile-play-pause').addClass('button-audio-left');
                    $('.mobile-play-pause').addClass('left-0');
                    $('.mobile-play-pause').parent().parent().css('border-right-style','none');
                }else if (hidePrint) {
                    $('.button-print').parent().hide();
                    $('.mobile-play-pause').addClass('button-audio-left');
                    $('.mobile-play-pause').addClass('left-second');
                    $('.mobile-play-pause').parent().parent().css('border-right-style','none');
                }else if (hideGlossary) {
                    $('.mobile-glossary').addClass('d-n');
                    $('.mobile-play-pause').addClass('button-audio-left');
                    $('.mobile-play-pause').addClass('left-zero');
                    $('.mobile-play-pause').addClass('left-second');
                    $('.mobile-play-pause').parent().parent().css('border-right-style','none');
                    $('.button-print').parent().addClass('left-0');
                }
            }



            
        };

        var _activeTopicName = function(){
            var color = _course.getParam('navigation-topic-name-color');
            var bg_color = _course.getParam('navigation-topic-name-background-color');
            $("#screen").prepend("<div class=\"topic-name-contaner\" style=\"background-color:"+bg_color+";\"><div class=\"topic-name-text\" style=\"color:"+color+";\"></div></div>");
            $(".mobile-navigation .pointer-navigation-container").css({'background-color':bg_color,'color':color});
        };

        var _setGradient = function(element, startColor, endColor, direction, alpha) {
            if (startColor !== '' && endColor !== '') {
                var position = ['top', 'left bottom', 'to bottom', '0'];
                if (direction !== '') {
                    position = (direction === 'V') ? ['top', 'left bottom', 'to bottom', '0'] : ['left top', 'right top', 'to right', '1'];
                }
                element.css('filter', "progid:DXImageTransform.Microsoft.gradient(startColorStr='" + ((alpha !== '') ? _dec2hexAndOpacityIE(startColor, alpha) : startColor) + "', EndColorStr='" + ((alpha !== '') ? _dec2hexAndOpacityIE(endColor, alpha) : endColor) + "', GradientType='" + position[3] + "')")
                        .css('background-image', '-moz-linear-gradient(' + position[0] + ', ' + ((alpha !== '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + ' 0%, ' + ((alpha !== '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + ' 100%)')
                        .css('background-image', 'linear-gradient(' + position[0] + ', ' + ((alpha !== '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + ' 0%, ' + ((alpha !== '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + ' 100%)')
                        .css('background-image', '-o-linear-gradient(' + position[0] + ', ' + ((alpha !== '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + ' 0%, ' + ((alpha !== '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + ' 100%)')
                        .css('background-image', '-webkit-linear-gradient(' + position[0] + ', ' + ((alpha !== '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + ' 0%, ' + ((alpha !== '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + ' 100%)')
                        .css('background-image', '-ms-linear-gradient(' + position[0] + ', ' + ((alpha !== '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + ' 0%, ' + ((alpha !== '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + ' 100%)')
                        .css('background-image', '-webkit-gradient(linear, left top, ' + position[1] + ', from(' + ((alpha !== '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + '), to(' + ((alpha !== '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + '))')
                        .css('background-image', 'linear-gradient(' + position[2] + ', ' + ((alpha !== '') ? _hex2rgbAndOpacity(startColor, alpha) : startColor) + ' 0%, ' + ((alpha !== '') ? _hex2rgbAndOpacity(endColor, alpha) : endColor) + ' 100%)')
                        .css('background-color', '');
            }
        };

        var _setNavigationGradientColors = function() {

            var _navigationBackgroundGradientStartColor = _course.getParam('navigation-background-gradient-start-color');
            var _navigationBackgroundGradientEndColor = _course.getParam('navigation-background-gradient-end-color');
            var _topRowNavigationGradientStartColor = _course.getParam('top-row-navigation-gradient-start-color');
            var _topRowNavigationGradientEndColor = _course.getParam('top-row-navigation-gradient-end-color');
            var _centerRowNavigationGradientStartColor = _course.getParam('center-row-navigation-gradient-start-color');
            var _centerRowNavigationGradientEndColor = _course.getParam('center-row-navigation-gradient-end-color');
            var _bottomRowNavigationGradientStartColor = _course.getParam('bottom-row-navigation-gradient-start-color');
            var _bottomRowNavigationGradientEndColor = _course.getParam('bottom-row-navigation-gradient-end-color');
            var _boxGradientStartColor = _course.getParam('box-frame-gradient-start-color');
            var _boxGradientEndColor = _course.getParam('box-frame-gradient-end-color');
            var _logoNavigationBackgroundGradientStartColor = _course.getParam('logo-navigation-gradient-start-color');
            var _logoNavigationBackgroundGradientEndColor = _course.getParam('logo-navigation-gradient-end-color');
            var _pointerRowNavigationGradientStartColor = _course.getParam('pointer-row-navigation-gradient-start-color-vertical');
            var _pointerRowNavigationGradientEndColor = _course.getParam('pointer-row-navigation-gradient-end-color-vertical');
            var _pointerRowNavigationBackgroundColor = _course.getParam('pointer-row-navigation-background-color-vertical');

            // For desktop-menu
            _setGradient($('.desktop-navigation'), _navigationBackgroundGradientStartColor, _navigationBackgroundGradientEndColor, _course.getParam('navigation-background-gradient-direction'), 1); // _course.getParam('navigation-background-alpha')
            _setGradient($('.top-navigation-container.main', '.desktop-navigation'), _topRowNavigationGradientStartColor, _topRowNavigationGradientEndColor, _course.getParam('top-row-navigation-gradient-direction'), _course.getParam('top-row-navigation-alpha'))
            _setGradient($('.center-navigation-container.main'), _centerRowNavigationGradientStartColor, _centerRowNavigationGradientEndColor, _course.getParam('center-row-navigation-gradient-direction'), _course.getParam('center-row-navigation-alpha'))
            _setGradient($('.bottom-navigation-container.main'), _bottomRowNavigationGradientStartColor, _bottomRowNavigationGradientEndColor, _course.getParam('bottom-row-navigation-gradient-direction'), _course.getParam('bottom-row-navigation-alpha'))
            //_setGradient($('.logo-container'), _logoNavigationBackgroundGradientStartColor, _logoNavigationBackgroundGradientEndColor, _course.getParam('logo-navigation-background-gradient-direction'), _course.getParam('logo-navigation-alpha'))
            _setGradient($('.logo-container'), _logoNavigationBackgroundGradientStartColor, _logoNavigationBackgroundGradientEndColor, _course.getParam('logo-navigation-gradient-direction'), _course.getParam('logo-navigation-alpha'))
            // For mobile-menu
            _setGradient($('.top-navigation-container.main', '.mobile-navigation'), _navigationBackgroundGradientStartColor, _navigationBackgroundGradientEndColor, _course.getParam('navigation-background-gradient-direction'), 1); // _course.getParam('navigation-background-alpha')
            _setGradient($('.pointer-navigation-container', '.mobile-navigation'), _pointerRowNavigationGradientStartColor, _pointerRowNavigationGradientEndColor, _course.getParam('pointer-row-navigation-gradient-direction-vertical'), _course.getParam('pointer-row-navigation-alpha-vertical'))

            // _setGradient($('.menu-container'), _boxGradientStartColor, _boxGradientEndColor);

            _setNavigationButtonsRowPosition();
        };

        var _setNavigationButtonsRowPosition = function() {
            var _buttonsRowNavigationPosition = _course.getParam('buttons-row-navigation-position');
            if (_buttonsRowNavigationPosition !== '') {
                var _tools = $('.tools', '.navigation-container', '.desktop-navigation');
                var _progress = $('.progress', '.navigation-container', '.desktop-navigation');
                var _empty = $('.empty', '.navigation-container', '.desktop-navigation');
                var _buttonsRowNavigationBorderColor = _course.getParam('buttons-row-navigation-border-color');
                var _buttonsNavigationColor = _course.getParam('buttons-navigation-color');

                $('.button-toggle-audio').css('color', _buttonsNavigationColor);
                $('.icon-leftarrow').css('color', _buttonsNavigationColor);
                $('.icon-rightarrow').css('color', _buttonsNavigationColor);
                $('.icon-home').css('color', _buttonsNavigationColor);
                $('.button-print').css('color', _buttonsNavigationColor);
                $('.button-glossary').css('color', _buttonsNavigationColor);

                // For desktop-menu
                if (_buttonsRowNavigationPosition == '1') {
                    if (_course.getParam('top-row-navigation-background-color') !== '')
                        _setVerticalNavigationTopRowParams('top');
                    $('.top-navigation-container.main', '.navigation-container', '.desktop-navigation').html(_tools);
                    if (_buttonsRowNavigationBorderColor !== '') {
                        $('.left-navigation-container', '.top-navigation-container.main', '.desktop-navigation').css('border-color', _buttonsRowNavigationBorderColor);
                        $('.middle-navigation-container', '.top-navigation-container.main', '.desktop-navigation').css('border-color', _buttonsRowNavigationBorderColor);
                    };
                    $('.center-navigation-container.main', '.navigation-container', '.desktop-navigation').html(_empty);
                    $('.bottom-navigation-container.main', '.navigation-container', '.desktop-navigation').html(_progress);
                } else if (_buttonsRowNavigationPosition == '2') {
                    _setVerticalNavigationTopRowParams('center');
                    $('.top-navigation-container.main', '.navigation-container', '.desktop-navigation').html(_progress);
                    $('.center-navigation-container.main', '.navigation-container', '.desktop-navigation').html(_tools);
                    if (_buttonsRowNavigationBorderColor !== '') {
                        $('.left-navigation-container', '.center-navigation-container.main', '.desktop-navigation').css('border-color', _buttonsRowNavigationBorderColor);
                        $('.middle-navigation-container', '.center-navigation-container.main', '.desktop-navigation').css('border-color', _buttonsRowNavigationBorderColor);
                    };
                    //$('.bottom-navigation-container.main', '.navigation-container', '.desktop-navigation').html(_empty);
                    if (_course.getParam('show-topic-title') == null || _course.getParam('show-topic-title') == '') {
                        $('.bottom-navigation-container.main', '.navigation-container', '.desktop-navigation').html(_empty);
                    }
                    else {
                        var topicTitleContainer = $("<div class='title-topic'></div>");
                        $('.bottom-navigation-container.main', '.navigation-container', '.desktop-navigation').html(topicTitleContainer);
                    }

                } else if (_buttonsRowNavigationPosition == '3') {
                    _setVerticalNavigationTopRowParams('bottom');
                    $('.top-navigation-container.main', '.navigation-container', '.desktop-navigation').html(_progress);
                    $('.center-navigation-container.main', '.navigation-container', '.desktop-navigation').html(_empty);
                    $('.bottom-navigation-container.main', '.navigation-container', '.desktop-navigation').html(_tools);
                    if (_buttonsRowNavigationBorderColor !== '') {
                        $('.left-navigation-container', '.bottom-navigation-container.main', '.desktop-navigation').css('border-color', _buttonsRowNavigationBorderColor);
                        $('.middle-navigation-container', '.bottom-navigation-container.main', '.desktop-navigation').css('border-color', _buttonsRowNavigationBorderColor);
                    };
                }
            }
        };

        var _setVerticalNavigationTopRowParams = function(itemRowPosition) {
            var _itemRowPositionNavigationColor = _course.getParam(itemRowPosition + '-row-navigation-background-color');
            var _itemRowPositionNavigationTextColor = _course.getParam(itemRowPosition + '-row-navigation-text-color');
            var _itemRowPositionNavigationGradientStartColor = _course.getParam(itemRowPosition + '-row-navigation-gradient-start-color');
            var _itemRowPositionNavigationGradientEndColor = _course.getParam(itemRowPosition + '-row-navigation-gradient-end-color');
            var _buttonsRowNavigationBorderColor = _course.getParam('buttons-row-navigation-border-color');
            var _navigationBackgroundImage = _course.getParam('navigation-background-image');
            var _navigationBackgroundType = _course.getParam('navigation-background-type');
            var _buttonsNavigationColor = _course.getParam('buttons-navigation-color');

            $('.button-toggle-audio').css('color', _buttonsNavigationColor);
            $('.icon-leftarrow').css('color', _buttonsNavigationColor);
            $('.icon-rightarrow').css('color', _buttonsNavigationColor);
            $('.icon-home').css('color', _buttonsNavigationColor);
            $('.button-print').css('color', _buttonsNavigationColor);
            $('.button-glossary').css('color', _buttonsNavigationColor);

            // For mobile-menu
            if (_itemRowPositionNavigationColor !== '') {
                $('.navigation-container', '.top-navigation-container.main', '.mobile-navigation').css('background-color', _itemRowPositionNavigationColor)
            };
            if (_itemRowPositionNavigationTextColor !== '') {
                $('.navigation-container', '.top-navigation-container.main', '.mobile-navigation').css('color', _itemRowPositionNavigationTextColor)
            };
            if (_navigationBackgroundType !== 'image' && _navigationBackgroundImage == '') {
                    _setGradient($('.navigation-container', '.top-navigation-container.main', '.mobile-navigation'), _itemRowPositionNavigationGradientStartColor, _itemRowPositionNavigationGradientEndColor, _course.getParam(itemRowPosition + '-row-navigation-gradient-direction'), _course.getParam(itemRowPosition + '-row-navigation-alpha'))
            }
            if (_buttonsRowNavigationBorderColor !== '') {
                $('.left-navigation-container', '.top-navigation-container.main', '.mobile-navigation').css('border-color', _buttonsRowNavigationBorderColor);
                $('.middle-navigation-container', '.top-navigation-container.main', '.mobile-navigation').css('border-color', _buttonsRowNavigationBorderColor);
                $('.right-navigation-container', '.top-navigation-container.main', '.mobile-navigation').css('border-color', _buttonsRowNavigationBorderColor);
            };
        };

        var _resize = function() {
//            $('.background-image', '.desktop-navigation').css("height", $('.desktop-navigation').height());
//            $('.background-image', '.mobile-navigation').css("height", $('.top-navigation-container', '.mobile-navigation').height());
            if ($('.logo-background-image', '.desktop-navigation')[0])
                $('.logo-background-image', '.desktop-navigation').css("height", $('.logo-container', '.desktop-navigation').height());
            if ($('.logo-background-image', '.mobile-navigation')[0])
                $('.logo-background-image', '.mobile-navigation').css("height", $('.logo-container', '.mobile-navigation').height());
        };

        var _setNavigationImage = function(navigationitem, navigationBackgroundImage, navigationBackgroundClassName, zIndexPosition, uploadImageActive) {
            var current_item = navigationitem;
            var imageSprite = 'nav' + navigationBackgroundImage.replace("navigation_background_","").replace("jpg","png");
            var image = 'img/trans.gif';
            var background = 'url(img/'+imageSprite+')';

            if (uploadImageActive) {
                image = 'img/' + navigationBackgroundImage;
                background = "none";
            }

            current_item.prepend($("<img />").attr({
                "class": navigationBackgroundClassName,
                "src": image,
                "alt": current_item.content
            }).css({
                position: "absolute", 
                width: "100%", 
                height: "100%", 
                top: "0", 
                left: "0", 
                margin: 0,
                padding: 0, 
                border: "none", 
                zIndex: zIndexPosition,
                backgroundImage: background, // imageSprite
                backgroundPosition:'0 0%',
                backgroundSize:'100% 200%'
            }));
        };

        function _hex2rgbAndOpacity(hex, opacity) {
            var h = hex.replace('#', '');
            h = h.match(new RegExp('(.{' + h.length / 3 + '})', 'g'));
            for (var i = 0; i < h.length; i++)
                h[i] = parseInt(h[i].length == 1 ? h[i] + h[i] : h[i], 16);
            if (typeof opacity != 'undefined')
                h.push(opacity);
            return 'rgba(' + h.join(',') + ')';
        }

        function _dec2hexAndOpacityIE(hex, opacity) {
            var d;
            if (typeof opacity != 'undefined')
                d = Math.floor(opacity * 255).toString(16);
            var h = hex.replace('#', '');
            d = d + h;
            return '#' + d;
        }

    }
});

$(function() {
    $.navigation.initialize();
    $(window).resize();
});
